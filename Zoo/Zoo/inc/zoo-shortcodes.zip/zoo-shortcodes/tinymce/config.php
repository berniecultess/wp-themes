<?php


/*-----------------------------------------------------------------------------------*/
/*	Columns Config
/*-----------------------------------------------------------------------------------*/
$zoo_shortcodes['columns'] = array(
	'params' => array(),
	'shortcode' => ' {{child_shortcode}} ',
	'popup_title' => __('Insert Columns Shortcode', 'textdomain'),
	'no_preview' => true,
	'child_shortcode' => array(
		'params' => array(
			'column' => array(
				'type' => 'select',
				'label' => __('Column Type', 'textdomain'),
				'desc' => __('Select the type, ie width of the column.', 'textdomain'),
				'options' => array(
					'column_full' => 'Full Width',
					'column_third' => 'One Third',
					'column_third_last' => 'One Third Last',
					'column_two_thirds' => 'Two Thirds',
					'column_two_thirds_last' => 'Two Thirds Last',
					'column_half' => 'One Half',
					'column_half_last' => 'One Half Last',
					'column_quarter' => 'One Quarter',
					'column_quarter_last' => 'One Quarter Last',
					'column_three_quarter' => 'Three Quarters',
					'column_three_quarter_last' => 'Three Quarters Last',
				
				)
			),
			'content' => array(
				'std' => '',
				'type' => 'textarea',
				'label' => __('Column Content', 'textdomain'),
				'desc' => __('Add the column content.', 'textdomain'),
			)
		),
		'shortcode' => '[{{column}}] {{content}} [/{{column}}] ',
		'clone_button' => __('Add Column', 'textdomain')
	)
);

/*-----------------------------------------------------------------------------------*/
/*	Button Config
/*-----------------------------------------------------------------------------------*/
$zoo_shortcodes['button'] = array(
	'no_preview' => true,
	'params' => array(
		'link' => array(
			'type' => 'text',
			'label' => __('Link', 'textdomain'),
			'desc' => __('Enter the buttons URL. For in page links use #PageTitle eg - #About (Case Sensitive)', 'textdomain'),
			'std' => '#About',
		),
		'transparent' => array(
			'type' => 'select',
			'label' => __('Button Style', 'textdomain'),
			'desc' => __('Transparent button or solid color?', 'textdomain'),
			'options' => array(
					'yes' => 'Transparent',
					'no' => 'Solid Color',
				),
		),
		'label' => array(
			'type' => 'text',
			'label' => __('Button Label', 'textdomain'),
			'desc' => __('Enter the button label', 'textdomain'),
			'std' => '',
		),
	),
	'shortcode' => '[button link="{{link}}" transparent="{{transparent}}"]{{label}}[/button]',
	'popup_title' => __('Insert Button Shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Skill Config
/*-----------------------------------------------------------------------------------*/
$zoo_shortcodes['skill'] = array(
	'no_preview' => true,
	'params' => array(
		'name' => array(
			'type' => 'text',
			'label' => __('Skill', 'textdomain'),
			'desc' => __('Add a title to go above the skill rating bar', 'textdomain'),
			'std' => 'Skill',
		),
		'level' => array(
			'type' => 'text',
			'label' => __('Skill Level', 'textdomain'),
			'desc' => __('Add the level of skill between 0% and 100%', 'textdomain'),
			'std' => '100',
		),
	),
	'shortcode' => '[skill name="{{name}}" level="{{level}}"]',
	'popup_title' => __('Insert Skill Rating Bar Shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Scroll Animation Config
/*-----------------------------------------------------------------------------------*/
$zoo_shortcodes['scrollAnimation'] = array(
	'no_preview' => true,
	'params' => array(
		'start' => array(
			'type' => 'rangetext',
			'label' => __('Start', 'textdomain'),
			'desc' => __('Enter the scroll position where the animation will begin', 'textdomain'),
			'std' => '',
		),
		'end' => array(
			'type' => 'rangetext',
			'label' => __('End', 'textdomain'),
			'desc' => __('Enter the scroll position where the animation will end', 'textdomain'),
			'std' => '',
		),
		'relative' => array(
			'type' => 'select',
			'label' => __('Mode', 'textdomain'),
			'desc' => __('Are the start and end values based on document height or relative to the browser view port - Recommended', 'textdomain'),
			'options' => array(
					'yes' => 'Relative to view port',
					'no' => 'Based on document height',
				),
		),
		'fromStyle' => array(
			'type' => 'style',
			'label' => __('Animate From', 'textdomain'),
			'desc' => __('Use the sliders below to set the property and value that the animation will tween from. Will also accept custom CSS.', 'textdomain'),
			'std' => '',
		),
		'fromOpacity' => array(
			'type' => 'range',
			'desc' => '',
			'label' => __('Opacity', 'textdomain'),
			'std' => '',
		),
		'fromTop' => array(
			'type' => 'range',
			'desc' => '',
			'label' => __('Top', 'textdomain'),
			'std' => '',
		),
		'fromLeft' => array(
			'type' => 'range',
			'desc' => '',
			'label' => __('Left', 'textdomain'),
			'std' => '',
		),
		'toStyle' => array(
			'type' => 'style',
			'label' => __('Animate To', 'textdomain'),
			'desc' => __('Enter the values the animation will tween to. Properites must match the animating from properties', 'textdomain'),
			'std' => '',
		),
		'toOpacity' => array(
			'type' => 'range',
			'desc' => '',
			'label' => __('Opacity', 'textdomain'),
			'std' => '',
		),
		'toTop' => array(
			'type' => 'range',
			'desc' => '',
			'label' => __('Top', 'textdomain'),
			'std' => '',
		),
		'toLeft' => array(
			'type' => 'range',
			'desc' => '',
			'label' => __('Left', 'textdomain'),
			'std' => '',
		),
	),
	'shortcode' => '[scroll_animation relative="{{relative}}" start="{{start}}" end="{{end}}" from="{{fromStyle}}" to="{{toStyle}}"][/scroll_animation]',
	'popup_title' => __('Insert Scroll Animation Shortcode <a class="help" href ="http://www.webdingo.net/zoo-doc/#animation" target="_blank">Help</a>', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Recent Posts Config
/*-----------------------------------------------------------------------------------*/
$zoo_shortcodes['recentPosts'] = array(
	'no_preview' => true,
	'params' => array(
		'numPosts' => array(
			'type' => 'text',
			'label' => __('Number of posts', 'textdomain'),
			'desc' => __('Add the number of posts to show', 'textdomain'),
			'std' => '3'
		),
		'excerptWords' => array(
			'type' => 'text',
			'label' => __('Excerpt Words', 'textdomain'),
			'desc' => __('Add the amount of words for auto generated excerpts', 'textdomain'),
			'std' => '75',
		),
	),
	'shortcode' => '[recent_posts num_posts="{{numPosts}}" excerpt_words="{{excerptWords}}"]',
	'popup_title' => __('Insert Recent Posts Shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Flex Slider Config
/*-----------------------------------------------------------------------------------*/
$zoo_shortcodes['flexSlider'] = array(
	'no_preview' => true,
	'params' => array(
		'cat' => array(
			'type' => 'text',
			'label' => __('Flex Slider Category', 'textdomain'),
			'desc' => __('Enter the flex slider post category to show', 'textdomain'),
			'std' => '',
		),
	),
	'shortcode' => '[flex_slider cat="{{cat}}"]',
	'popup_title' => __('Insert Recent Posts Shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Parallax Section Config
/*-----------------------------------------------------------------------------------*/
$zoo_shortcodes['parallaxSection'] = array(
	'no_preview' => true,
	'params' => array(
		'background' => array(
			'type' => 'text',
			'label' => __('Background Image', 'textdomain'),
			'desc' => __('Enter the background image URL', 'textdomain'),
			'std' => '',
		),
	),
	'shortcode' => '[parallax_section background="{{background}}"][/parallax_section]',
	'popup_title' => __('Insert Parallax Section Shortcode', 'textdomain')
);


/*-----------------------------------------------------------------------------------*/
/*	Colored Parallax Section Config
/*-----------------------------------------------------------------------------------*/
$zoo_shortcodes['coloredParallaxSection'] = array(
	'no_preview' => true,
	'params' => array(
		'background' => array(
			'type' => 'text',
			'label' => __('Background Image', 'textdomain'),
			'desc' => __('Enter the background image URL', 'textdomain'),
			'std' => '',
		),

		'fromColor' => array(
			'type' => 'rangecolor',
			'label' => __('Starting Color', 'textdomain'),
			'desc' => __('Use the sliders below to select a starting color', 'textdomain'),
			'std' => 'rgb(255,255,255)',
		),
		'fromRed' => array(
			'type' => 'range',
			'desc' => '',
			'label' => __('Red', 'textdomain'),
			'std' => '',
		),
		'fromGreen' => array(
			'type' => 'range',
			'desc' => '',
			'label' => __('Green', 'textdomain'),
			'std' => '',
		),
		'fromBlue' => array(
			'type' => 'range',
			'desc' => '',
			'label' => __('Blue', 'textdomain'),
			'std' => '',
		),
		'toColor' => array(
			'type' => 'rangecolor',
			'label' => __('End Color', 'textdomain'),
			'desc' => __('Use the sliders below to select a ending color', 'textdomain'),
			'std' => 'rgb(0,0,0)',
		),
		'toRed' => array(
			'type' => 'range',
			'desc' => '',
			'label' => __('Red', 'textdomain'),
			'std' => '',
		),
		'toGreen' => array(
			'type' => 'range',
			'desc' => '',
			'label' => __('Green', 'textdomain'),
			'std' => '',
		),
		'toBlue' => array(
			'type' => 'range',
			'desc' => '',
			'label' => __('Blue', 'textdomain'),
			'std' => '',
		),


	),
	'shortcode' => '[colored_parallax_section background="" start="{{fromColor}}" end="{{toColor}}"][/colored_parallax_section]',
	'popup_title' => __('Insert Colred Parallax Section Shortcode <a class="help" href ="http://www.webdingo.net/zoo-doc/#animation" target="_blank">Help</a>', 'textdomain')
);




/*-----------------------------------------------------------------------------------*/
/*	Parallax Background Config
/*-----------------------------------------------------------------------------------*/
$zoo_shortcodes['parallaxBackground'] = array(
	'no_preview' => true,
	'params' => array(
		'background' => array(
			'type' => 'text',
			'label' => __('Background Image', 'textdomain'),
			'desc' => __('Enter the background image URL', 'textdomain'),
			'std' => '',
		),
	),
	'shortcode' => '[parallax_background background="{{background}}"][/parallax_section]',
	'popup_title' => __('Insert Parallax Background Shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Tabbed Page Config
/*-----------------------------------------------------------------------------------*/
$zoo_shortcodes['tabbedPage'] = array(
    'params' => array(),
    'no_preview' => true,
    'shortcode' => '[tabbed_page] {{child_shortcode}}  [/tabbed_page]',
    'popup_title' => __('Insert Tab Shortcode', 'textdomain'),
    
    'child_shortcode' => array(
        'params' => array(
            'title' => array(
                'std' => 'Title',
                'type' => 'text',
                'label' => __('Tab Title', 'textdomain'),
                'desc' => __('Title of the tab', 'textdomain'),
            ),
            'content' => array(
                'std' => 'Tab Content',
                'type' => 'textarea',
                'label' => __('Tab Content', 'textdomain'),
                'desc' => __('Add the tab content', 'textdomain')
            )
        ),
        'shortcode' => '[tabbed_page_tab title="{{title}}"] {{content}} [/tabbed_page_tab]',
        'clone_button' => __('Add Tab', 'textdomain')
    )
);

/*-----------------------------------------------------------------------------------*/
/*	Google Map Config
/*-----------------------------------------------------------------------------------*/
$zoo_shortcodes['googleMap'] = array(
	'no_preview' => true,
	'params' => array(
		'title' => array(
			'type' => 'text',
			'label' => __('Map Title', 'textdomain'),
			'desc' => __('Enter the map title', 'textdomain'),
			'std' => 'Envato Office',
		),
		'location' => array(
			'type' => 'text',
			'label' => __('Location', 'textdomain'),
			'desc' => __('Enter Map Address', 'textdomain'),
			'std' => '2 Elizabeth St, Melbourne Victoria 3000 Australia',
		),
		'zoom' => array(
			'type' => 'text',
			'label' => __('Zoom', 'textdomain'),
			'desc' => __('Enter the defaut zoom level', 'textdomain'),
			'std' => '10',
		),
		'height' => array(
			'type' => 'text',
			'label' => __('Height', 'textdomain'),
			'desc' => __('Enter the map height in pixels', 'textdomain'),
			'std' => '350',
		),
	),
	'shortcode' => '[google_map title="{{title}}" location="{{location}}" zoom="{{zoom}}" height={{height}}]',
	'popup_title' => __('Insert Google Map shortcode', 'textdomain')
);

/*-----------------------------------------------------------------------------------*/
/*	Tabbed Page Config
/*-----------------------------------------------------------------------------------*/
$zoo_shortcodes['testimonialsSlider'] = array(
    'params' => array(),
    'no_preview' => true,
    'shortcode' => '[testimonials_slider] {{child_shortcode}}  [/testimonials_slider]',
    'popup_title' => __('Testimonials Slider Shortcode', 'textdomain'),
    
    'child_shortcode' => array(
        'params' => array(
            'image' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Testimonial Image', 'textdomain'),
                'desc' => __('Enter the URL for testimonial avatar', 'textdomain'),
            ),
            'name' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Name', 'textdomain'),
                'desc' => __('Enter the name of the testimonial author', 'textdomain'),
            ),
            'company' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Company', 'textdomain'),
                'desc' => __('Enter the company of the testimonial author', 'textdomain'),
            ),
            'content' => array(
                'std' => '',
                'type' => 'textarea',
                'label' => __('Quote', 'textdomain'),
                'desc' => __('Add the quote content', 'textdomain')
            )
        ),
        'shortcode' => '[testimonial image="{{image}}" name="{{name}}" company="{{company}}"] {{content}} [/testimonial]',
        'clone_button' => __('Add Testimonial', 'textdomain')
    )
);


?>

