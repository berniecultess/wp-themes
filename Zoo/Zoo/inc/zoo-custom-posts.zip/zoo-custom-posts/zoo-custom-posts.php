<?php
/*
Plugin Name: Zoo Custom Posts
Plugin URI: http://www.webdingo.net/zoo/
Description: Custom post types for Zoo
Version: 1.0
Author: WebDingo
Author URI: http://www.webdingo.net
*/

/*-----------------------------------------------------------------------------------*/
/*	Flex Slider
/*-----------------------------------------------------------------------------------*/
if (!function_exists('zoo_custom_post_flex_slider')) {
	function zoo_custom_post_flex_slider() {
		$labels = array(
			'name'               => _x( 'Flex Sliders', 'post type general name' ),
			'singular_name'      => _x( 'Flex Slider', 'post type singular name' ),
			'add_new'            => _x( 'Add New', 'slider' ),
			'add_new_item'       => __( 'Add New Slide' ),
			'edit_item'          => __( 'Edit Slide' ),
			'new_item'           => __( 'New Slide' ),
			'all_items'          => __( 'All Slides' ),
			'view_item'          => __( 'View Slide' ),
			'search_items'       => __( 'Search Sliders' ),
			'not_found'          => __( 'No sliders found' ),
			'not_found_in_trash' => __( 'No sliders found in the Trash' ), 
			'menu_name'          => 'Flex Slider'
		);
		$args = array(
			'labels'        => $labels,
			'description'   => 'Flex Slider Slides',
			'public'        => true,
			'menu_position' => null,
			'supports'      => array( 'title', 'editor', 'thumbnail' ),
			'exclude_from_search' => true,
		);
		register_post_type( 'flex_slider', $args );	
	}
	add_action( 'init', 'zoo_custom_post_flex_slider' );
}
/*-----------------------------------------------------------------------------------*/
/*	Super Slider
/*-----------------------------------------------------------------------------------*/

if (!function_exists('zoo_custom_post_super_slider')) {
	function zoo_custom_post_super_slider() {
		$labels = array(
			'name'               => _x( 'SuperSlides', 'post type general name' ),
			'singular_name'      => _x( 'SuperSlides Slide', 'post type singular name' ),
			'add_new'            => _x( 'Add New', 'Slide' ),
			'add_new_item'       => __( 'Add New Slide' ),
			'edit_item'          => __( 'Edit Slide' ),
			'new_item'           => __( 'New Slide' ),
			'all_items'          => __( 'All Slides' ),
			'view_item'          => __( 'View Slide' ),
			'search_items'       => __( 'Search Slide' ),
			'not_found'          => __( 'No sliders found' ),
			'not_found_in_trash' => __( 'No sliders found in the Trash' ), 
			'menu_name'          => 'SuperSlides'
		);
		$args = array(
			'labels'        => $labels,
			'description'   => 'Super Slider / Home Page Slider Slides',
			'public'        => true,
			'menu_position' => null,
			'supports'      => array( 'title', 'editor', 'thumbnail' ),
			'exclude_from_search' => true,
		);
		register_post_type( 'super_slider', $args );	
	}
	add_action( 'init', 'zoo_custom_post_super_slider' );
}
/*-----------------------------------------------------------------------------------*/
/*	Portfolio
/*-----------------------------------------------------------------------------------*/

if (!function_exists('zoo_custom_post_portfolio')) {
	function zoo_custom_post_portfolio() {
		$labels = array(
			'name'               => _x( 'Portfolio Items', 'post type general name' ),
			'singular_name'      => _x( 'Portfolio Item', 'post type singular name' ),
			'add_new'            => _x( 'Add New', 'Item' ),
			'add_new_item'       => __( 'Add New Item' ),
			'edit_item'          => __( 'Edit Portfolio Item' ),
			'new_item'           => __( 'New Portfolio Item' ),
			'all_items'          => __( 'All Items' ),
			'view_item'          => __( 'View Item' ),
			'search_items'       => __( 'Search Portfolios' ),
			'not_found'          => __( 'No items found' ),
			'not_found_in_trash' => __( 'No items found in the Trash' ), 
			'menu_name'          => 'Portfolio'
		);
		$args = array(
			'labels'        => $labels,
			'description'   => 'Portfolio Items',
			'public'        => true,
			'menu_position' => null,
			'supports'      => array( 'title', 'editor', 'thumbnail' ),
			'exclude_from_search' => true,
		);
		register_post_type( 'portfolios', $args );	
	}
	add_action( 'init', 'zoo_custom_post_portfolio' );
}
/*-----------------------------------------------------------------------------------*/
/*	Taxonomies
/*-----------------------------------------------------------------------------------*/

if (!function_exists('create_zoo_taxonomies')) {
	function create_zoo_taxonomies() {
	    register_taxonomy(
	        'flex_slider_category',
	        'flex_slider',
	        array(
	            'labels' => array(
	                'name' => 'Flex Slider Categories',
	                'add_new_item' => 'Add New Flex Slider Category',
	                'new_item_name' => "New Flex Slider Category",
	            ),
	            'show_ui' => true,
	            'show_tagcloud' => false,
	            'hierarchical' => true,
	        )
	    );
	    register_taxonomy(
	        'portfolio_item_category',
	        'portfolios',
	        array(
	            'labels' => array(
	                'name' => 'Portfolio Categories',
	                'add_new_item' => 'Add New Portfolio Category',
	                'new_item_name' => "New Portfolio Category"
	            ),
	            'show_ui' => true,
	            'show_tagcloud' => false,
	            'hierarchical' => true
	        )
	    );
	}
	add_action( 'init', 'create_zoo_taxonomies', 0 );
}

?>