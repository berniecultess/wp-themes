/*global jQuery, document*/
jQuery(document).ready(function () {
    /*
     *
     * Zoo_Options_date function
     * Adds datepicker js
     *
     */
    jQuery('.zoo-opts-datepicker').datepicker();
});
