jQuery(document).ready(function(){
	jQuery(".be-img-select").msDropDown();
});
