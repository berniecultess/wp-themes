<?php
/**
 * Content Wrappers
 */
?>

<div><div>

	<?php
		/**
		 * woocommerce_sidebar hook
		 *
		 * @hooked woocommerce_get_sidebar - 10
		 */
		do_action('woocommerce_sidebar');
	?>
	
<div id="inner" class="woocommerce">