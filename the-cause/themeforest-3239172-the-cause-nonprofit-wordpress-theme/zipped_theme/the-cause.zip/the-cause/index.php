<?php
/*
@package WordPress
@subpackage The Cause
*/

get_template_part('archive');

?>