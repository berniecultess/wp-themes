<?php
/*
	@package WordPress
	@subpackage The Cause
*/
?>

<!-- SIDEBAR -->
<div id="sidebar" class="<?php tb_write_bckg('sidebar'); ?> shopSidebar">
<?php dynamic_sidebar( 'Shop' ); ?>
</div>
<!-- SIDEBAR -->