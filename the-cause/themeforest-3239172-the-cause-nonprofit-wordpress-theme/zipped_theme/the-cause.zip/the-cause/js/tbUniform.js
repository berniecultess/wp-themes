/*jQuery(document).ready(function($) {
	$('<p class="donation"></p>').insertAfter('form.ewd_form select[name*="amount"]');
	$('form.ewd_form select[name*="amount"] option').each(function(i, e) {
	optValue = $(this).val();
    	$('<label class="radioLabel"><input type="radio" name="amount" value="' + optValue +'">' + optValue + "</label>")
        .appendTo('p.donation');
	});
});

jQuery(document).ready(function($) {
	$("#tbForm select, .ewd_form select, .variations select, .checkout select, .shipping_calculator select, .edit_address select, input:text, .ewd_form input:radio").uniform();
	
	$('form.ewd_form select[name*="amount"]').parent().hide();
	
	$('#getInvolved select.narrow').parent().addClass('narrow');
});*/