<?php
/*
	@package WordPress
	@subpackage The Cause
*/
?>

<!-- SIDEBAR -->
<div id="sidebar" class="<?php tb_write_bckg('sidebar'); ?>">
<?php dynamic_sidebar( 'Events' ); ?>
</div>
<!-- SIDEBAR -->