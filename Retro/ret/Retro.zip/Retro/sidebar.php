<div id="blog_section_content_right" class="blog_section_sidebar">

	<?php dynamic_sidebar( retro_get_sidebar( ( isset( $post ) && ! is_home() ? $post->ID : false ) ) ); ?>
	
	<div class="clr"></div>
	
</div>
<!-- end div #blog_section_content_right -->

<div class="clr"></div>