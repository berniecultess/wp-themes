<h1><?php echo retro_filter( __('Not found', 'haku') ); ?></h1>

<p><?php _e('Sorry, we couldn&rsquo;t find who you were looking for.', 'haku'); ?></p>

<br />

<?php get_search_form(); ?>